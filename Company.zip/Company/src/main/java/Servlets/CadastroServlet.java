package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CadastroServlet")
public class CadastroServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserManager userManager = new UserManager();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email_cadastro");
        String senha = request.getParameter("senha_cadastro");

        if (email != null && senha != null) {
            userManager.addUser(email, senha);

            response.sendRedirect("Login.jsp");
        } else {
            response.sendRedirect("Cadastro.jsp?error=1");
        }
    }
}
