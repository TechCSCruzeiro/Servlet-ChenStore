package Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AutenticationServlet")
public class AutenticationServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private List<User> users = new ArrayList<>();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("email_login");
        String password = request.getParameter("senha_login");

        boolean validUser = checkUser(username, password);

        if (validUser) {
            response.sendRedirect("Home.jsp");
        } else {
            response.sendRedirect("Login.jsp?error=1");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email_cadastro");
        String senha = request.getParameter("senha_cadastro");

        if (email != null && senha != null) {
            addUser(email, senha);

            response.sendRedirect("Login.jsp");
        } else {
            response.sendRedirect("Cadastro.jsp?error=1");
        }
    }

    private void addUser(String email, String senha) {
        User newUser = new User(email, senha);
        users.add(newUser);
    }

    private boolean checkUser(String email, String senha) {
        for (User user : users) {
            if (user.getUsername().equals(email) && user.getPassword().equals(senha)) {
                return true;
            }
        }
        return false;
    }
}
