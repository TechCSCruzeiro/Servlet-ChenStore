package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String parcelas = "";
    	
    	String nomeTitular = request.getParameter("nome_titular");
    	String numeroCartao = request.getParameter("numero_cartao");
    	String dataValidade = request.getParameter("data_validade");
    	String codigoSeguranca = request.getParameter("codigo_seguranca");
    	String valorTotal = request.getParameter("valor_total");
    	String formaPagamento = request.getParameter("forma_pagamento");

    	if(formaPagamento.equals("Credito")){
    		parcelas = request.getParameter("parcelas");
    	}

    	if (nomeTitular != null) {

    	    request.setAttribute("nome_titular", nomeTitular);
    	    request.setAttribute("numero_cartao", numeroCartao);
    	    request.setAttribute("data_validade", dataValidade);
    	    request.setAttribute("codigo_seguranca", codigoSeguranca);
    	    request.setAttribute("valor_total", valorTotal);
    	    request.setAttribute("forma_pagamento", formaPagamento);
    	    
    	    if(formaPagamento.equals("Credito")) {
        	    request.setAttribute("parcelas", parcelas);

        	}

    	    request.getRequestDispatcher("NotaFiscal.jsp").forward(request, response);
    	} else {
    	    // Pagamento falhou, redireciona para uma página de erro
    	    response.sendRedirect("erro.jsp");
    	}
    }
}

