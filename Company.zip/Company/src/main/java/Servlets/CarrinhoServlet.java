package Servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/carrinho-servlet")
public class CarrinhoServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String carrinhoItens = request.getParameter("carrinhoItens");
        
        if (carrinhoItens != null) {
            String[] itemStrings = carrinhoItens.split(",");
            List<Product> produtos = new ArrayList<>();

            for (String itemString : itemStrings) {
                String[] itemParts = itemString.split("\\|");

                if (itemParts.length == 3) {
                    String productName = itemParts[0];
                    double productPrice = Double.parseDouble(itemParts[1]);
                    int productQuantity = Integer.parseInt(itemParts[2]);

                    Product produto = new Product(productName, productPrice, productQuantity);
                    produtos.add(produto);
                }
            }

            request.setAttribute("produtos", produtos);
            request.getRequestDispatcher("Carrinho.jsp").forward(request, response);
        } else {
            response.sendRedirect("Cadastro.jsp?error=1");
        }
    }
}
