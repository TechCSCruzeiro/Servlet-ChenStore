package Servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ProcessarPagamentoServlet")
public class ProcessarPagamentoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String quantidadeStr = request.getParameter("quantidade");
        String precoStr = request.getParameter("preco");

        if (quantidadeStr != null && !quantidadeStr.isEmpty() && precoStr != null && !precoStr.isEmpty()) {
            try {
                int quantidade = Integer.parseInt(quantidadeStr);
                double preco = Double.parseDouble(precoStr);

                double total = quantidade * preco;

                request.setAttribute("total", total);

                request.getRequestDispatcher("Resultado.jsp").forward(request, response);
            } catch (NumberFormatException e) {
                response.sendRedirect("erro.jsp");
            }
        } else {
            response.sendRedirect("erro.jsp");
        }
    }
}
