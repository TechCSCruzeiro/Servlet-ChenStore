package Servlets;

public class Product {
    private String Nome;
    private double Preco;
    private int Quantidade;

    public Product(String nome, double preco, int quantidade) {
        this.Nome = nome;
        this.Preco = preco;
        this.Quantidade = quantidade;
    }
}
