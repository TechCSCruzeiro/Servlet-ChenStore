package Servlets;

import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private Map<String, User> users = new HashMap<>();

    public UserManager() {
        // Inicialize a lista de usuários com alguns valores de exemplo
        addUser("user1", "password1");
        addUser("user2", "password2");
    }

    public void addUser(String username, String password) {
        users.put(username, new User(username, password));
    }

    public boolean checkUser(String username, String password) {
        User user = users.get(username);
        return user != null && user.getPassword().equals(password);
    }
}

